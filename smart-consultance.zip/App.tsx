import React, { useState } from 'react';
import ParentView from './components/ParentView';
import DoctorView from './components/DoctorView';
import DoctorDashboard from './components/DoctorDashboard';
import { AppView, Ticket, ConsultationStatus, Role } from './types';
import { MOCK_TICKETS } from './services/mockData';
import { User, Stethoscope, ArrowRight } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LANDING);
  const [tickets, setTickets] = useState<Ticket[]>(MOCK_TICKETS);
  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  
  // For the current parent session
  const [parentName, setParentName] = useState('');
  const [currentParentTicketId, setCurrentParentTicketId] = useState<string | null>(null);

  // --- Actions ---

  const startParentSession = (name: string, age: string) => {
      const newTicket: Ticket = {
          id: Date.now().toString(),
          patientName: name,
          patientAge: age,
          status: ConsultationStatus.TRIAGE,
          createdAt: new Date(),
          lastUpdate: new Date(),
          summary: null,
          messages: [{
            id: 'init',
            role: Role.MODEL,
            text: `Hello ${name}. I'm SmartConsult. I'm here to help triage your child (${age}) symptoms. In a few words, what's worrying you most right now?`,
            timestamp: new Date()
          }]
      };
      setTickets(prev => [...prev, newTicket]);
      setCurrentParentTicketId(newTicket.id);
      setCurrentView(AppView.PARENT_TRIAGE);
  };

  const updateTicket = (ticketId: string, updates: Partial<Ticket>) => {
      setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, ...updates, lastUpdate: new Date() } : t));
  };

  const handleDoctorAccept = (ticketId: string) => {
      updateTicket(ticketId, { status: ConsultationStatus.ACTIVE });
      setActiveTicketId(ticketId);
      setCurrentView(AppView.DOCTOR_ACTIVE);
  };

  // --- Views ---

  if (currentView === AppView.LANDING) {
      return (
          <div className="h-screen w-screen bg-slate-900 flex items-center justify-center p-6">
              <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-8">
                  
                  {/* Parent Card */}
                  <div className="bg-white rounded-2xl p-8 shadow-2xl flex flex-col items-center text-center space-y-6 hover:scale-105 transition-transform duration-300">
                      <div className="w-20 h-20 bg-teal-100 text-teal-600 rounded-full flex items-center justify-center">
                          <User size={40} />
                      </div>
                      <div>
                          <h2 className="text-2xl font-bold text-slate-800">I am a Parent</h2>
                          <p className="text-slate-500 mt-2">Worried about your child? Get an instant AI triage and connect with a doctor.</p>
                      </div>
                      <div className="w-full space-y-3 text-left">
                          <div>
                            <label className="text-xs font-bold text-slate-400 uppercase">Child's Name</label>
                            <input 
                                id="pName"
                                type="text" 
                                className="w-full border border-slate-200 rounded-lg px-4 py-2 mt-1 focus:ring-2 focus:ring-teal-500" 
                                placeholder="e.g. Alice"
                            />
                          </div>
                          <div>
                            <label className="text-xs font-bold text-slate-400 uppercase">Child's Age</label>
                            <input 
                                id="pAge"
                                type="text" 
                                className="w-full border border-slate-200 rounded-lg px-4 py-2 mt-1 focus:ring-2 focus:ring-teal-500" 
                                placeholder="e.g. 3 years"
                            />
                          </div>
                      </div>
                      <button 
                        onClick={() => {
                            const name = (document.getElementById('pName') as HTMLInputElement).value || 'Patient';
                            const age = (document.getElementById('pAge') as HTMLInputElement).value || 'Child';
                            setParentName(name);
                            startParentSession(name, age);
                        }}
                        className="w-full bg-teal-600 text-white font-bold py-3 rounded-xl hover:bg-teal-700 transition-colors flex items-center justify-center"
                      >
                          Start Triage <ArrowRight size={18} className="ml-2" />
                      </button>
                  </div>

                  {/* Doctor Card */}
                  <div className="bg-slate-800 rounded-2xl p-8 shadow-2xl flex flex-col items-center text-center space-y-6 hover:scale-105 transition-transform duration-300 border border-slate-700">
                      <div className="w-20 h-20 bg-indigo-900 text-indigo-400 rounded-full flex items-center justify-center">
                          <Stethoscope size={40} />
                      </div>
                      <div>
                          <h2 className="text-2xl font-bold text-white">I am a Doctor</h2>
                          <p className="text-slate-400 mt-2">Access the clinical dashboard, review triage summaries, and accept patients.</p>
                      </div>
                      <div className="w-full pt-12">
                         <button 
                            onClick={() => setCurrentView(AppView.DOCTOR_DASHBOARD)}
                            className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition-colors flex items-center justify-center"
                        >
                            Enter Dashboard <ArrowRight size={18} className="ml-2" />
                        </button>
                      </div>
                  </div>

              </div>
          </div>
      );
  }

  // --- Parent Workflow ---
  
  if (currentView === AppView.PARENT_TRIAGE || currentView === AppView.PARENT_ACTIVE) {
      const ticket = tickets.find(t => t.id === currentParentTicketId);
      if (!ticket) return <div>Error: Session not found</div>;

      return (
        <div className="h-screen bg-slate-50">
             {/* Simple Navbar for Parent to see they are in the app */}
             {ticket.status !== ConsultationStatus.ACTIVE && (
                <div className="absolute top-4 left-4 z-50">
                    <button onClick={() => setCurrentView(AppView.LANDING)} className="text-xs text-slate-400 hover:text-slate-600">Exit</button>
                </div>
             )}
            <ParentView 
                currentTicket={ticket}
                updateTicket={updateTicket}
            />
        </div>
      );
  }

  // --- Doctor Workflow ---

  if (currentView === AppView.DOCTOR_DASHBOARD) {
      return (
          <div className="h-screen flex flex-col">
              <div className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-indigo-900 font-bold text-lg">
                      <Stethoscope className="text-indigo-600" /> SmartConsult <span className="text-slate-400 font-normal">MD</span>
                  </div>
                  <button onClick={() => setCurrentView(AppView.LANDING)} className="text-sm text-slate-500 hover:text-indigo-600">Logout</button>
              </div>
              <DoctorDashboard 
                tickets={tickets} 
                onAcceptTicket={handleDoctorAccept} 
              />
          </div>
      );
  }

  if (currentView === AppView.DOCTOR_ACTIVE && activeTicketId) {
      const ticket = tickets.find(t => t.id === activeTicketId);
      if (!ticket) return <div>Ticket not found</div>;

      return (
        <div className="h-screen">
             <DoctorView 
                ticket={ticket} 
                updateTicket={updateTicket}
                onBack={() => {
                    setActiveTicketId(null);
                    setCurrentView(AppView.DOCTOR_DASHBOARD);
                }}
             />
        </div>
      );
  }

  return <div>Unknown State</div>;
};

export default App;
