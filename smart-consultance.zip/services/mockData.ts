import { Ticket, ConsultationStatus, RiskLevel, Role } from '../types';

export const MOCK_TICKETS: Ticket[] = [
  {
    id: 'mock-1',
    patientName: 'Emma Thompson',
    patientAge: '4yo',
    status: ConsultationStatus.WAITING,
    createdAt: new Date(Date.now() - 1000 * 60 * 15), // 15 mins ago
    lastUpdate: new Date(),
    messages: [
      { id: 'm1', role: Role.MODEL, text: 'Hello, I am SmartConsult.', timestamp: new Date() },
      { id: 'm2', role: Role.USER, text: 'My daughter has a weird rash and high fever.', timestamp: new Date() }
    ],
    summary: {
      chiefComplaint: "High Fever & Rash",
      riskLevel: RiskLevel.HIGH,
      redFlags: ["High Fever > 39C", "Non-blanching rash"],
      keySymptoms: ["Fever", "Lethargy", "Rash"],
      summary: "4yo female presenting with sudden onset high fever and spreading rash. Parent reports child is lethargic.",
      urgency: "Immediate Review",
      patientAge: "4yo"
    }
  },
  {
    id: 'mock-2',
    patientName: 'Liam Chen',
    patientAge: '8mo',
    status: ConsultationStatus.WAITING,
    createdAt: new Date(Date.now() - 1000 * 60 * 45), // 45 mins ago
    lastUpdate: new Date(),
    messages: [
        { id: 'm1', role: Role.MODEL, text: 'Hello.', timestamp: new Date() },
        { id: 'm2', role: Role.USER, text: 'He has been coughing a lot at night.', timestamp: new Date() }
    ],
    summary: {
      chiefComplaint: "Nocturnal Cough",
      riskLevel: RiskLevel.LOW,
      redFlags: [],
      keySymptoms: ["Dry cough", "No fever"],
      summary: "8mo male with persistent dry cough at night. No respiratory distress reported.",
      urgency: "Routine Review",
      patientAge: "8mo"
    }
  }
];
