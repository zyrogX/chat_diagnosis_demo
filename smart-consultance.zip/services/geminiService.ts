import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Message, CaseSummary, RiskLevel, SoapNote, Role } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// System instruction for the Parent Triage Bot
const PARENT_SYSTEM_INSTRUCTION = `
You are "SmartConsult," an empathetic, specialized AI pediatric triage assistant. 
Your goal is to calm worried parents, gather clinical history for a child, and assess urgency.
Phase 1: Open listening. Validate feelings. Ask for the primary complaint.
Phase 2: Structured history. Ask about HPI (Onset, duration, severity) and ROS (Fever, hydration, breathing, activity).
Phase 3: Case Summary.
Rules:
- Be warm, concise, and professional.
- Do not provide a definitive medical diagnosis.
- If a red flag is detected (difficulty breathing, lethargy, high fever in infants), advise seeking care immediately.
- Use simple language suitable for stressed parents.
`;

export const generateTriageResponse = async (history: Message[]): Promise<string> => {
  try {
    const model = "gemini-2.5-flash";
    
    // Convert history to format expected by Gemini
    // We explicitly cast role to string to satisfy the SDK's strictly typed Content interface
    const contents = history
      .filter(m => m.role !== Role.SYSTEM)
      .map(m => ({
        role: m.role as string,
        parts: [{ text: m.text }]
      }));
    
    // Note: The history array passed in already contains the latest user message.
    // We do NOT need to append currentInput again.

    const response = await ai.models.generateContent({
      model,
      contents,
      config: {
        systemInstruction: PARENT_SYSTEM_INSTRUCTION,
        temperature: 0.7,
      }
    });

    return response.text || "I'm having a little trouble connecting. Could you please repeat that?";
  } catch (error) {
    console.error("Gemini Triage Error:", error);
    return "I apologize, but I'm currently experiencing high traffic. Please proceed to the nearest clinic if this is an emergency.";
  }
};

const CASE_SUMMARY_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    chiefComplaint: { type: Type.STRING },
    riskLevel: { type: Type.STRING, enum: [RiskLevel.LOW, RiskLevel.MODERATE, RiskLevel.HIGH, RiskLevel.CRITICAL] },
    redFlags: { type: Type.ARRAY, items: { type: Type.STRING } },
    keySymptoms: { type: Type.ARRAY, items: { type: Type.STRING } },
    summary: { type: Type.STRING },
    urgency: { type: Type.STRING },
    patientAge: { type: Type.STRING }
  },
  required: ["chiefComplaint", "riskLevel", "summary", "urgency"]
};

export const generateCaseSummary = async (history: Message[]): Promise<CaseSummary> => {
  try {
    const transcript = history.map(m => `${m.role}: ${m.text}`).join('\n');
    const prompt = `Analyze the following pediatric consultation transcript and generate a structured clinical summary. \n\nTranscript:\n${transcript}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: CASE_SUMMARY_SCHEMA,
        temperature: 0.2
      }
    });

    if (response.text) {
        const data = JSON.parse(response.text);
        // Ensure array fields are actually arrays to prevent UI crashes
        return {
            ...data,
            redFlags: Array.isArray(data.redFlags) ? data.redFlags : [],
            keySymptoms: Array.isArray(data.keySymptoms) ? data.keySymptoms : []
        } as CaseSummary;
    }
    throw new Error("Empty response");
  } catch (error) {
    console.error("Gemini Summary Error:", error);
    return {
      chiefComplaint: "Error generating summary",
      riskLevel: RiskLevel.MODERATE,
      redFlags: [],
      keySymptoms: [],
      summary: "Manual review required. The system could not auto-summarize this case.",
      urgency: "Review required"
    };
  }
};

export const generateDifferentialDiagnosis = async (summary: CaseSummary): Promise<string> => {
    try {
        const prompt = `
        Based on this pediatric case summary, provide a differential diagnosis.
        Format as:
        1. **Most Likely**: [Diagnosis] - [Reasoning]
        2. **Consider**: [Diagnosis] - [Reasoning]
        3. **Rule Out**: [Diagnosis] - [Reasoning]
        
        Case: ${JSON.stringify(summary)}
        `;
        
        const response = await ai.models.generateContent({
            model: "gemini-3-pro-preview", // Using pro for complex reasoning
            contents: prompt
        });
        return response.text || "Unable to generate diagnosis.";
    } catch (e) {
        console.error("Diagnosis Error", e);
        return "Error generating diagnosis.";
    }
};

export const generateSoapNote = async (history: Message[]): Promise<SoapNote> => {
    try {
        const transcript = history.map(m => `${m.role}: ${m.text}`).join('\n');
        const prompt = `Create a SOAP note from this transcript.`;
        
        const schema: Schema = {
            type: Type.OBJECT,
            properties: {
                subjective: { type: Type.STRING },
                objective: { type: Type.STRING },
                assessment: { type: Type.STRING },
                plan: { type: Type.STRING }
            }
        };

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt + `\n\nTranscript:\n${transcript}`,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema
            }
        });
         if (response.text) {
            return JSON.parse(response.text) as SoapNote;
        }
        throw new Error("Empty response");
    } catch (e) {
        console.error("SOAP Note Error", e);
        return {
            subjective: "Error generating note",
            objective: "Error generating note",
            assessment: "Error generating note",
            plan: "Error generating note"
        };
    }
}

export const generateDraftResponse = async (lastUserMessage: string, summary: CaseSummary): Promise<string> => {
    try {
        const prompt = `
        You are a pediatrician. Draft a short, professional, yet warm response to the parent based on the latest context.
        Context: ${summary.summary}
        Parent's last concern: "${lastUserMessage}"
        Keep it under 3 sentences.
        `;
         const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt
        });
        return response.text || "";
    } catch (e) {
        return "Thank you for providing that information. Let me review your case.";
    }
}