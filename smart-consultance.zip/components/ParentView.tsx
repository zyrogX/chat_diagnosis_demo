import React, { useState, useEffect } from 'react';
import { Message, Role, CaseSummary, ConsultationStatus, Ticket } from '../types';
import { generateTriageResponse, generateCaseSummary } from '../services/geminiService';
import ChatInterface from './ChatInterface';
import StressGauge from './StressGauge';
import VideoCall from './VideoCall';
import { Send, Mic, Camera, ShieldCheck, Loader2, Video, MessageSquare } from 'lucide-react';

interface ParentViewProps {
  currentTicket: Ticket;
  updateTicket: (ticketId: string, updates: Partial<Ticket>) => void;
}

const ParentView: React.FC<ParentViewProps> = ({ currentTicket, updateTicket }) => {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isFinishing, setIsFinishing] = useState(false);
  const [activeTab, setActiveTab] = useState<'chat' | 'video'>('chat');

  const messages = currentTicket.messages;

  // Auto-switch to video tab if doctor connects and status becomes active
  useEffect(() => {
    if (currentTicket.status === ConsultationStatus.ACTIVE) {
        // Play notification sound or visual cue here
    }
  }, [currentTicket.status]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: Role.USER,
      text: input,
      timestamp: new Date()
    };

    const newHistory = [...messages, userMsg];
    updateTicket(currentTicket.id, { messages: newHistory });
    setInput('');
    setIsLoading(true);

    try {
      const responseText = await generateTriageResponse(newHistory);
      
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: Role.MODEL,
        text: responseText,
        timestamp: new Date()
      };
      updateTicket(currentTicket.id, { messages: [...newHistory, botMsg] });
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFinish = async () => {
    setIsFinishing(true);
    const summary = await generateCaseSummary(messages);
    updateTicket(currentTicket.id, { 
        summary: summary,
        status: ConsultationStatus.WAITING
    });
    setIsFinishing(false);
  };

  // 1. WAITING ROOM VIEW
  if (currentTicket.status === ConsultationStatus.WAITING) {
      return (
          <div className="flex-1 flex flex-col items-center justify-center bg-slate-50 p-6 text-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg mb-6 relative">
                 <ShieldCheck size={40} className="text-teal-600" />
                 <span className="absolute top-0 right-0 flex h-4 w-4">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-4 w-4 bg-teal-500"></span>
                 </span>
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">Triage Complete</h2>
              <p className="text-slate-500 max-w-md mb-8">
                  We have forwarded your case summary to our pediatric team. A doctor is reviewing your details and will connect shortly.
              </p>
              
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 w-full max-w-md text-left">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Summary Sent to Doctor</h3>
                  <div className="space-y-3">
                      <div>
                          <span className="text-sm font-semibold text-slate-700 block">Chief Complaint</span>
                          <span className="text-sm text-slate-600">{currentTicket.summary?.chiefComplaint}</span>
                      </div>
                       <div>
                          <span className="text-sm font-semibold text-slate-700 block">Assessment</span>
                          <span className="text-sm text-slate-600">{currentTicket.summary?.summary}</span>
                      </div>
                       <div className="pt-2 border-t border-slate-100 mt-2">
                           <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                               Waiting for Physician...
                           </span>
                       </div>
                  </div>
              </div>
          </div>
      );
  }

  // 2. ACTIVE DOCTOR CONNECTION VIEW
  if (currentTicket.status === ConsultationStatus.ACTIVE) {
      return (
        <div className="flex flex-col h-full bg-slate-50">
            {/* Header */}
            <div className="bg-white p-4 border-b border-slate-200 flex items-center justify-between shadow-sm z-10">
                 <div className="flex items-center gap-3">
                     <div className="relative">
                        <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white">
                            <span className="font-bold">Dr</span>
                        </div>
                        <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
                     </div>
                     <div>
                         <h1 className="font-bold text-slate-800 text-sm">Dr. Sarah Jensen</h1>
                         <p className="text-xs text-green-600 font-medium">Online • Pediatrician</p>
                     </div>
                 </div>
                 
                 <div className="flex bg-slate-100 rounded-lg p-1">
                     <button 
                        onClick={() => setActiveTab('chat')}
                        className={`p-2 rounded-md transition-all ${activeTab === 'chat' ? 'bg-white shadow text-indigo-600' : 'text-slate-400'}`}
                     >
                         <MessageSquare size={20} />
                     </button>
                     <button 
                        onClick={() => setActiveTab('video')}
                        className={`p-2 rounded-md transition-all ${activeTab === 'video' ? 'bg-white shadow text-indigo-600' : 'text-slate-400'}`}
                     >
                         <Video size={20} />
                     </button>
                 </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-hidden relative">
                {activeTab === 'chat' ? (
                     <div className="h-full flex flex-col">
                        <ChatInterface messages={messages} isLoading={isLoading} />
                        <div className="p-4 bg-white border-t border-slate-100">
                            <div className="flex items-center gap-2">
                                <input
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    className="flex-1 bg-slate-100 border-0 rounded-full px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                                    placeholder="Message doctor..."
                                />
                                <button 
                                    onClick={handleSend}
                                    className="p-3 bg-indigo-600 text-white rounded-full hover:bg-indigo-700"
                                >
                                    <Send size={18} />
                                </button>
                            </div>
                        </div>
                     </div>
                ) : (
                    <div className="h-full p-4">
                        <VideoCall 
                            participantName="Dr. Sarah Jensen" 
                            isDoctor={true} 
                            onEndCall={() => setActiveTab('chat')} 
                        />
                    </div>
                )}
            </div>
        </div>
      );
  }

  // 3. TRIAGE VIEW (Default)
  return (
    <div className="flex flex-col h-full bg-slate-50 md:max-w-md md:mx-auto md:border-x md:border-slate-200 shadow-xl">
      {/* Header */}
      <div className="bg-white p-4 border-b border-slate-100 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-teal-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-teal-200">
            <ShieldCheck size={20} />
          </div>
          <div>
            <h1 className="font-bold text-slate-800 leading-tight">Smart Consult</h1>
            <p className="text-xs text-slate-500">AI Triage Assistant</p>
          </div>
        </div>
      </div>

      <div className="px-4 py-2 bg-slate-50/90 backdrop-blur-sm sticky top-[72px] z-10">
        <StressGauge messages={messages} />
      </div>

      <ChatInterface messages={messages} isLoading={isLoading} />

      <div className="p-4 bg-white border-t border-slate-100">
        {messages.length > 3 && !isFinishing && (
             <button 
             onClick={handleFinish}
             className="w-full mb-3 bg-indigo-50 text-indigo-700 py-2 rounded-lg text-sm font-medium flex items-center justify-center hover:bg-indigo-100 transition-colors"
           >
             <ShieldCheck size={16} className="mr-2" />
             Review & Connect to Doctor
           </button>
        )}
        
        {isFinishing && (
            <div className="w-full mb-3 bg-amber-50 text-amber-700 py-3 rounded-lg text-sm font-medium flex items-center justify-center animate-pulse">
                Analyzing case details...
            </div>
        )}

        <div className="flex items-end gap-2">
          <button className="p-3 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition-colors">
            <Camera size={20} />
          </button>
          <button className="p-3 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition-colors">
            <Mic size={20} />
          </button>
          <div className="flex-1 relative">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Describe symptoms..."
              className="w-full bg-slate-100 border-0 rounded-2xl px-4 py-3 pr-10 focus:ring-2 focus:ring-indigo-500 resize-none text-slate-800 placeholder:text-slate-400 text-sm"
              rows={1}
            />
          </div>
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="p-3 bg-indigo-600 text-white rounded-full shadow-lg shadow-indigo-200 hover:bg-indigo-700 disabled:opacity-50 disabled:shadow-none transition-all"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ParentView;
