import React, { useState, useEffect } from 'react';
import { Ticket, Role, SoapNote } from '../types';
import { generateDifferentialDiagnosis, generateSoapNote, generateDraftResponse } from '../services/geminiService';
import VideoCall from './VideoCall';
import { AlertTriangle, FileText, Brain, MessageSquare, Send, Copy, Video, ChevronLeft } from 'lucide-react';

interface DoctorViewProps {
  ticket: Ticket;
  updateTicket: (ticketId: string, updates: Partial<Ticket>) => void;
  onBack: () => void;
}

const DoctorView: React.FC<DoctorViewProps> = ({ ticket, updateTicket, onBack }) => {
  const [activeTab, setActiveTab] = useState<'clinical' | 'chat' | 'video'>('clinical');
  const [differential, setDifferential] = useState<string>('');
  const [soapNote, setSoapNote] = useState<SoapNote | null>(null);
  const [draftResponse, setDraftResponse] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [input, setInput] = useState('');

  const summary = ticket.summary;
  const messages = ticket.messages;

  useEffect(() => {
    if (summary && !differential) {
      handleGenerateAI();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [summary]);

  const handleGenerateAI = async () => {
    if(!summary) return;
    setIsGenerating(true);
    
    // Fire off AI tasks
    generateDifferentialDiagnosis(summary).then(res => setDifferential(res));
    generateSoapNote(messages).then(res => setSoapNote(res));
    
    const lastUserMsg = [...messages].reverse().find(m => m.role === Role.USER)?.text || "";
    generateDraftResponse(lastUserMsg, summary).then(res => setDraftResponse(res));
    
    setIsGenerating(false);
  };

  const handleSendMessage = (text: string) => {
      const newMsg = {
          id: Date.now().toString(),
          role: Role.MODEL,
          text: text,
          timestamp: new Date()
      };
      updateTicket(ticket.id, { messages: [...messages, newMsg] });
      setInput('');
      if(activeTab === 'clinical') setDraftResponse('');
  }

  if (!summary) return <div>Loading case data...</div>;

  const riskColor = 
    summary.riskLevel === 'Critical' ? 'bg-red-100 text-red-700 border-red-200' :
    summary.riskLevel === 'High' ? 'bg-orange-100 text-orange-700 border-orange-200' :
    summary.riskLevel === 'Moderate' ? 'bg-yellow-100 text-yellow-700 border-yellow-200' :
    'bg-green-100 text-green-700 border-green-200';

  return (
    <div className="flex h-full bg-slate-100 overflow-hidden">
        
      {/* Left Sidebar: Patient Summary */}
      <div className="w-80 bg-white border-r border-slate-200 flex flex-col h-full overflow-y-auto">
        <div className="p-4 border-b border-slate-100">
            <button onClick={onBack} className="flex items-center text-slate-400 hover:text-slate-600 text-sm mb-4">
                <ChevronLeft size={16} /> Back to Dashboard
            </button>
            <div className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold border mb-4 ${riskColor}`}>
                <AlertTriangle size={12} className="mr-1" />
                RISK: {summary.riskLevel.toUpperCase()}
            </div>
            <h2 className="text-xl font-bold text-slate-800 mb-1">{ticket.patientName}</h2>
            <p className="text-sm text-slate-500 font-medium">{ticket.patientAge} • {summary.chiefComplaint}</p>
        </div>

        <div className="p-6 space-y-6">
            <div>
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Red Flags</h3>
                {summary.redFlags && summary.redFlags.length > 0 ? (
                    <ul className="space-y-2">
                        {summary.redFlags.map((flag, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-red-600 bg-red-50 p-2 rounded-md">
                                <AlertTriangle size={14} className="mt-0.5 flex-shrink-0" />
                                {flag}
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p className="text-sm text-slate-500 italic">No specific red flags detected.</p>
                )}
            </div>
            
            <div>
                 <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">AI Summary</h3>
                 <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
                     {summary.summary}
                 </p>
            </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Toolbar */}
        <div className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6">
            <div className="flex items-center gap-6">
                <button 
                    onClick={() => setActiveTab('clinical')}
                    className={`pb-5 pt-5 text-sm font-medium border-b-2 transition-colors ${activeTab === 'clinical' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
                >
                    Clinical Co-Pilot
                </button>
                <button 
                    onClick={() => setActiveTab('chat')}
                    className={`pb-5 pt-5 text-sm font-medium border-b-2 transition-colors ${activeTab === 'chat' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
                >
                    Chat ({messages.length})
                </button>
                 <button 
                    onClick={() => setActiveTab('video')}
                    className={`pb-5 pt-5 text-sm font-medium border-b-2 transition-colors ${activeTab === 'video' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
                >
                    Video Call
                </button>
            </div>
            <div className="flex gap-2">
                 <div className="px-3 py-1.5 text-xs font-medium text-green-600 bg-green-50 rounded-md border border-green-100 flex items-center">
                     <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                     Live Session Active
                 </div>
            </div>
        </div>

        {/* Workspace */}
        <div className="flex-1 overflow-y-auto bg-slate-50">
            
            {activeTab === 'clinical' && (
                <div className="p-6 grid grid-cols-2 gap-6 max-w-5xl mx-auto">
                    
                    {/* Draft Response */}
                    <div className="col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="p-4 border-b border-slate-100 bg-indigo-50/50 flex items-center justify-between">
                            <h3 className="text-sm font-bold text-indigo-900 flex items-center gap-2">
                                <MessageSquare size={16} /> AI Draft Response
                            </h3>
                        </div>
                        <div className="p-4">
                            <textarea 
                                className="w-full text-sm text-slate-700 border-0 focus:ring-0 resize-none bg-transparent"
                                rows={2}
                                value={draftResponse}
                                onChange={(e) => setDraftResponse(e.target.value)}
                                placeholder="Generating draft..."
                            />
                            <div className="mt-2 flex justify-end">
                                <button onClick={() => handleSendMessage(draftResponse)} className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-md hover:bg-indigo-700">
                                    <Send size={12} /> Send to Parent
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Diff Dx */}
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="p-4 border-b border-slate-100"><h3 className="text-sm font-bold flex gap-2"><Brain size={16} className="text-purple-500"/> Differential</h3></div>
                        <div className="p-4 prose prose-sm max-w-none text-slate-600 whitespace-pre-line">{differential || "Generating..."}</div>
                    </div>

                    {/* SOAP */}
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="p-4 border-b border-slate-100"><h3 className="text-sm font-bold flex gap-2"><FileText size={16} className="text-teal-500"/> SOAP Note</h3></div>
                        <div className="p-4 text-sm space-y-2">
                            {soapNote ? (
                                <>
                                <div><span className="font-bold">S:</span> {soapNote.subjective}</div>
                                <div><span className="font-bold">O:</span> {soapNote.objective}</div>
                                <div><span className="font-bold">A:</span> {soapNote.assessment}</div>
                                <div><span className="font-bold">P:</span> {soapNote.plan}</div>
                                </>
                            ) : "Generating..."}
                        </div>
                    </div>

                </div>
            )}

            {activeTab === 'chat' && (
                <div className="h-full flex flex-col p-6 max-w-3xl mx-auto">
                    <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                        {messages.map((m, i) => (
                             <div key={i} className={`flex flex-col ${m.role === Role.USER ? 'items-start' : 'items-end'}`}>
                                 <span className="text-xs text-slate-400 mb-1 capitalize">{m.role === Role.USER ? 'Parent' : 'You'}</span>
                                 <div className={`max-w-[80%] px-4 py-2 rounded-lg text-sm ${
                                     m.role === Role.USER 
                                     ? 'bg-slate-200 text-slate-700' 
                                     : 'bg-indigo-600 text-white'
                                 }`}>
                                     {m.text}
                                 </div>
                             </div>
                        ))}
                    </div>
                    <div className="flex gap-2">
                        <input 
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage(input)}
                            className="flex-1 bg-white border border-slate-200 rounded-lg px-4"
                            placeholder="Type a message..."
                        />
                        <button onClick={() => handleSendMessage(input)} className="p-3 bg-indigo-600 text-white rounded-lg"><Send size={18}/></button>
                    </div>
                </div>
            )}

            {activeTab === 'video' && (
                <div className="h-full p-4">
                     <VideoCall participantName={ticket.patientName} isDoctor={true} onEndCall={() => setActiveTab('clinical')} />
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default DoctorView;
