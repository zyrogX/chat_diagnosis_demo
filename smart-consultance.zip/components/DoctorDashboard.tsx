import React, { useState } from 'react';
import { Ticket, ConsultationStatus, RiskLevel } from '../types';
import { AlertTriangle, Clock, ChevronRight, Activity, ArrowUpDown, Calendar, Filter } from 'lucide-react';

interface DoctorDashboardProps {
  tickets: Ticket[];
  onAcceptTicket: (ticketId: string) => void;
}

type SortOption = 'risk' | 'time' | 'age' | 'complaint';

const DoctorDashboard: React.FC<DoctorDashboardProps> = ({ tickets, onAcceptTicket }) => {
  const [sortBy, setSortBy] = useState<SortOption>('risk');

  // Filter only waiting tickets
  const waitingTickets = tickets.filter(t => t.status === ConsultationStatus.WAITING);

  // Helper to parse "4yo", "8mo" into months for sorting
  const getAgeInMonths = (ageStr: string): number => {
    const num = parseInt(ageStr.replace(/[^0-9]/g, '') || '0');
    const lower = ageStr.toLowerCase();
    if (lower.includes('mo')) return num;
    if (lower.includes('d')) return num / 30;
    if (lower.includes('w')) return num / 4;
    return num * 12; // Default to years
  };

  // Sort Logic
  const sortedTickets = [...waitingTickets].sort((a, b) => {
    const summaryA = a.summary;
    const summaryB = b.summary;

    switch (sortBy) {
      case 'risk':
        // Critical (0) < High (1) < Moderate (2) < Low (3)
        const riskOrder = {
          [RiskLevel.CRITICAL]: 0,
          [RiskLevel.HIGH]: 1,
          [RiskLevel.MODERATE]: 2,
          [RiskLevel.LOW]: 3
        };
        const rA = summaryA ? riskOrder[summaryA.riskLevel] : 4;
        const rB = summaryB ? riskOrder[summaryB.riskLevel] : 4;
        return rA - rB;

      case 'time':
        // Oldest (Longest wait) first
        return a.createdAt.getTime() - b.createdAt.getTime();

      case 'age':
        // Youngest first
        return getAgeInMonths(a.patientAge) - getAgeInMonths(b.patientAge);

      case 'complaint':
        // Alphabetical
        const cA = summaryA?.chiefComplaint || '';
        const cB = summaryB?.chiefComplaint || '';
        return cA.localeCompare(cB);

      default:
        return 0;
    }
  });

  return (
    <div className="flex-1 bg-slate-50 p-8 overflow-y-auto">
      <div className="max-w-5xl mx-auto">
        
        {/* Header & Controls */}
        <div className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-800 mb-2">Patient Queue</h1>
            <p className="text-slate-500">Real-time triage list. {waitingTickets.length} patient(s) waiting.</p>
          </div>

          <div className="flex items-center gap-2 bg-white p-1 rounded-lg border border-slate-200 shadow-sm">
            <span className="text-xs font-bold text-slate-400 uppercase px-2 flex items-center gap-1">
              <Filter size={12} /> Sort By:
            </span>
            
            <button
              onClick={() => setSortBy('risk')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                sortBy === 'risk' ? 'bg-indigo-100 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              Risk Level
            </button>
            <button
              onClick={() => setSortBy('time')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                sortBy === 'time' ? 'bg-indigo-100 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              Wait Time
            </button>
             <button
              onClick={() => setSortBy('age')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                sortBy === 'age' ? 'bg-indigo-100 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              Age (Youngest)
            </button>
             <button
              onClick={() => setSortBy('complaint')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                sortBy === 'complaint' ? 'bg-indigo-100 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              Complaint
            </button>
          </div>
        </div>

        {sortedTickets.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 bg-white rounded-xl border border-dashed border-slate-300">
            <Activity className="w-12 h-12 text-slate-300 mb-4" />
            <p className="text-slate-500 font-medium">No patients waiting.</p>
            <p className="text-sm text-slate-400">Enjoy your coffee ☕</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {sortedTickets.map((ticket) => {
                const summary = ticket.summary;
                if (!summary) return null;

                const riskColor = 
                    summary.riskLevel === RiskLevel.CRITICAL ? 'bg-red-50 text-red-700 border-red-200' :
                    summary.riskLevel === RiskLevel.HIGH ? 'bg-orange-50 text-orange-700 border-orange-200' :
                    summary.riskLevel === RiskLevel.MODERATE ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                    'bg-green-50 text-green-700 border-green-200';

                return (
                    <div key={ticket.id} className="bg-white rounded-xl p-6 shadow-sm border border-slate-200 hover:shadow-md transition-shadow flex items-center gap-6">
                        {/* Risk Indicator */}
                        <div className={`w-24 h-24 rounded-lg flex flex-col items-center justify-center flex-shrink-0 border ${riskColor}`}>
                            <span className="text-2xl font-bold">{summary.riskLevel.charAt(0)}</span>
                            <span className="text-xs uppercase font-bold tracking-wider">{summary.riskLevel}</span>
                        </div>

                        {/* Info */}
                        <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-3 mb-1">
                                <h3 className="text-lg font-bold text-slate-900">{ticket.patientName}</h3>
                                <span className="text-sm text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                                  <Calendar size={10} className="text-slate-400"/> {ticket.patientAge}
                                </span>
                                <span className="flex items-center text-xs text-slate-400 ml-auto">
                                    <Clock size={12} className="mr-1" />
                                    {Math.floor((Date.now() - ticket.createdAt.getTime()) / 60000)}m ago
                                </span>
                            </div>
                            <p className="text-sm font-medium text-slate-800 mb-2">{summary.chiefComplaint}</p>
                            <p className="text-sm text-slate-500 line-clamp-2">{summary.summary}</p>
                            
                            {summary.redFlags.length > 0 && (
                                <div className="mt-3 flex gap-2">
                                    {summary.redFlags.map((flag, i) => (
                                        <span key={i} className="inline-flex items-center text-xs font-medium text-red-600 bg-red-50 px-2 py-1 rounded">
                                            <AlertTriangle size={10} className="mr-1" /> {flag}
                                        </span>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Action */}
                        <button 
                            onClick={() => onAcceptTicket(ticket.id)}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-medium text-sm transition-colors flex items-center shadow-lg shadow-indigo-200"
                        >
                            Review & Accept <ChevronRight size={16} className="ml-2" />
                        </button>
                    </div>
                );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default DoctorDashboard;