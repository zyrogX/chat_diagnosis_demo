import React, { useMemo } from 'react';
import { RadialBarChart, RadialBar, PolarAngleAxis, ResponsiveContainer } from 'recharts';

interface StressGaugeProps {
  messages: { text: string; role: string }[];
}

// A simple heuristic to estimate stress based on length, caps, and keywords
const calculateStress = (messages: { text: string; role: string }[]) => {
  const userMessages = messages.filter(m => m.role === 'user');
  if (userMessages.length === 0) return 30; // Baseline

  const lastMsg = userMessages[userMessages.length - 1].text;
  let score = 30;

  // Urgent keywords
  if (/fever|blood|breathing|blue|pain|scream|unconscious/i.test(lastMsg)) score += 30;
  // Exclamation marks
  if (lastMsg.includes('!')) score += 10;
  // All caps check (rough)
  const upperCaseCount = lastMsg.replace(/[^A-Z]/g, "").length;
  if (upperCaseCount > lastMsg.length / 2 && lastMsg.length > 10) score += 20;
  // Length
  if (lastMsg.length > 150) score += 10;

  return Math.min(Math.max(score, 10), 100);
};

const StressGauge: React.FC<StressGaugeProps> = ({ messages }) => {
  const score = useMemo(() => calculateStress(messages), [messages]);

  const data = [{ name: 'Stress', value: score }];
  
  let color = '#10b981'; // Green
  let label = 'Calm';
  if (score > 50) { color = '#f59e0b'; label = 'Anxious'; } // Orange
  if (score > 80) { color = '#ef4444'; label = 'High Stress'; } // Red

  return (
    <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-100 flex items-center justify-between">
      <div className="flex flex-col">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Parental Stress</span>
        <span className="text-lg font-bold" style={{ color }}>{label}</span>
      </div>
      <div className="w-16 h-16 relative">
        <ResponsiveContainer width="100%" height="100%">
          <RadialBarChart innerRadius="70%" outerRadius="100%" data={data} startAngle={90} endAngle={-270} barSize={10}>
             <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
            <RadialBar background dataKey="value" fill={color} cornerRadius={10} />
          </RadialBarChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-slate-600">
            {score}%
        </div>
      </div>
    </div>
  );
};

export default StressGauge;
