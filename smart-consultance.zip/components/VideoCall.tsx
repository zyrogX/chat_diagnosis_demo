import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Video, VideoOff, PhoneOff, User } from 'lucide-react';

interface VideoCallProps {
  participantName: string;
  isDoctor: boolean;
  onEndCall: () => void;
}

const VideoCall: React.FC<VideoCallProps> = ({ participantName, isDoctor, onEndCall }) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const localVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;

    const startCamera = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error("Error accessing camera:", err);
      }
    };

    if (!isVideoOff) {
        startCamera();
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isVideoOff]);

  return (
    <div className="h-full flex flex-col bg-slate-900 rounded-xl overflow-hidden relative">
      {/* Remote Video (Simulated) */}
      <div className="flex-1 bg-slate-800 flex items-center justify-center relative">
        <div className="absolute inset-0 flex items-center justify-center">
            {/* Simulation of remote stream */}
            <div className="text-center">
                <div className="w-32 h-32 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                    <User size={64} className="text-slate-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">{participantName}</h3>
                <p className="text-slate-400 text-sm">{isDoctor ? 'Consulting Pediatrician' : 'Parent'}</p>
                <p className="text-teal-400 text-xs mt-2">● Live Connection</p>
            </div>
        </div>
        
        {/* Local Video PiP */}
        <div className="absolute bottom-4 right-4 w-48 h-36 bg-black rounded-lg border-2 border-slate-700 shadow-xl overflow-hidden z-10">
             {!isVideoOff ? (
                 <video 
                    ref={localVideoRef} 
                    autoPlay 
                    muted 
                    playsInline 
                    className="w-full h-full object-cover transform scale-x-[-1]"
                 />
             ) : (
                 <div className="w-full h-full flex items-center justify-center bg-slate-800">
                     <User size={24} className="text-slate-500" />
                 </div>
             )}
        </div>
      </div>

      {/* Controls */}
      <div className="h-20 bg-slate-900/90 backdrop-blur border-t border-slate-800 flex items-center justify-center gap-6">
        <button 
            onClick={() => setIsMuted(!isMuted)}
            className={`p-4 rounded-full transition-all ${isMuted ? 'bg-red-500 text-white' : 'bg-slate-700 text-white hover:bg-slate-600'}`}
        >
            {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
        </button>
        
        <button 
            onClick={onEndCall}
            className="p-4 rounded-full bg-red-600 text-white hover:bg-red-700 shadow-lg transform hover:scale-105 transition-all"
        >
            <PhoneOff size={28} />
        </button>

        <button 
            onClick={() => setIsVideoOff(!isVideoOff)}
            className={`p-4 rounded-full transition-all ${isVideoOff ? 'bg-red-500 text-white' : 'bg-slate-700 text-white hover:bg-slate-600'}`}
        >
            {isVideoOff ? <VideoOff size={24} /> : <Video size={24} />}
        </button>
      </div>
    </div>
  );
};

export default VideoCall;
