import React, { useEffect, useRef } from 'react';
import { Message, Role } from '../types';
import { User, Stethoscope, Loader2 } from 'lucide-react';

interface ChatInterfaceProps {
  messages: Message[];
  isLoading: boolean;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, isLoading }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-hide">
      {messages.map((msg) => (
        <div
          key={msg.id}
          className={`flex gap-3 ${msg.role === Role.USER ? 'flex-row-reverse' : 'flex-row'}`}
        >
          <div
            className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
              msg.role === Role.USER ? 'bg-indigo-100 text-indigo-600' : 'bg-teal-100 text-teal-600'
            }`}
          >
            {msg.role === Role.USER ? <User size={16} /> : <Stethoscope size={16} />}
          </div>
          <div
            className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
              msg.role === Role.USER
                ? 'bg-indigo-600 text-white rounded-br-none'
                : 'bg-white text-slate-700 border border-slate-100 rounded-bl-none'
            }`}
          >
            {msg.text}
          </div>
        </div>
      ))}
      {isLoading && (
        <div className="flex gap-3 flex-row">
          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center">
            <Stethoscope size={16} />
          </div>
          <div className="bg-white border border-slate-100 rounded-2xl rounded-bl-none px-4 py-3 shadow-sm flex items-center">
             <Loader2 className="w-4 h-4 animate-spin text-teal-600 mr-2" />
             <span className="text-slate-500 text-xs">SmartConsult is thinking...</span>
          </div>
        </div>
      )}
      <div ref={bottomRef} />
    </div>
  );
};

export default ChatInterface;
