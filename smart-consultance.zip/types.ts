export enum Role {
  USER = 'user',
  MODEL = 'model',
  SYSTEM = 'system'
}

export interface Message {
  id: string;
  role: Role;
  text: string;
  timestamp: Date;
}

export enum RiskLevel {
  LOW = 'Low',
  MODERATE = 'Moderate',
  HIGH = 'High',
  CRITICAL = 'Critical'
}

export interface CaseSummary {
  chiefComplaint: string;
  riskLevel: RiskLevel;
  redFlags: string[];
  keySymptoms: string[];
  summary: string;
  patientAge?: string;
  urgency: string;
}

export interface SoapNote {
  subjective: string;
  objective: string;
  assessment: string;
  plan: string;
}

export enum ConsultationStatus {
  TRIAGE = 'TRIAGE',        // Parent talking to AI
  WAITING = 'WAITING',      // AI finished, waiting for Doctor
  ACTIVE = 'ACTIVE',        // Doctor accepted, session live
  COMPLETED = 'COMPLETED'   // Session closed
}

export interface Ticket {
  id: string;
  patientName: string;
  patientAge: string;
  messages: Message[];
  summary: CaseSummary | null;
  status: ConsultationStatus;
  createdAt: Date;
  lastUpdate: Date;
}

export enum AppView {
  LANDING = 'LANDING',
  PARENT_TRIAGE = 'PARENT_TRIAGE',
  PARENT_WAITING = 'PARENT_WAITING',
  PARENT_ACTIVE = 'PARENT_ACTIVE',
  DOCTOR_DASHBOARD = 'DOCTOR_DASHBOARD',
  DOCTOR_ACTIVE = 'DOCTOR_ACTIVE'
}
